<?php $__env->startComponent('mail::message'); ?>
Hola

Estás recibiendo este correo por que hiciste una solicitud de recuperacion de
contraseña para tu cuenta.

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/admin/nuevo-password?token='.$token]); ?>
Recuperar contraseña
<?php echo $__env->renderComponent(); ?>

Si no realizaste esta solicitud, no se requiere realizar ninguna otra acción.

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\developer\indicadores-back\resources\views/mails/passwordReset.blade.php ENDPATH**/ ?>