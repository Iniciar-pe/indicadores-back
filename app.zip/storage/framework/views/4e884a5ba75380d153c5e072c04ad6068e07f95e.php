<?php echo e($slot); ?>

<?php /**PATH C:\developer\indicadores-back\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>